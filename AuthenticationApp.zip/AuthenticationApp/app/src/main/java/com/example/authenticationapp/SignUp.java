package com.example.authenticationapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import static com.example.authenticationapp.R.id.phone;

public class SignUp extends AppCompatActivity {

    //Variables
    TextInputLayout regName, regUsername, regEmail, regPhone, regPassword;
    Button regbtn, regTologinbtn;


     private FirebaseDatabase rootNode;
     private FirebaseAuth fAuth;
     private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_sign_up);

        regName = findViewById(R.id.Name);
        regUsername = findViewById(R.id.username);
        regEmail = findViewById(R.id.email);
        regPhone = findViewById(phone);
        regPassword = findViewById(R.id.password);
        regbtn = findViewById(R.id.go1);
        regTologinbtn = findViewById(R.id.regTologinbtn);

        //saving the data in firebase
        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                fAuth = FirebaseAuth.getInstance();

                String reg_Email = regEmail.getEditText().getText().toString().trim();
                String reg_Password = regPassword.getEditText().getText().toString().trim();

                        //fAuth.createUserWithEmailAndPassword(reg_Email, reg_Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            //@Override
                            //public void onComplete(@NonNull Task<AuthResult> task) {
                               // if(task.isSuccessful()) {
                                  //  Toast.makeText(SignUp.this, "Registration Successful", Toast.LENGTH_LONG).show();
                                //}else{
                              //      Toast.makeText(SignUp.this,"Registration failed",Toast.LENGTH_LONG).show();
                            //    }
                          //  }
                        //});

                        rootNode = FirebaseDatabase.getInstance();
                        reference = rootNode.getReference("users");

                //Get all the values
                String name = regName.getEditText().getText().toString();
                String username = regUsername.getEditText().getText().toString();
                String password = regPassword.getEditText().getText().toString();
                String email = regEmail.getEditText().getText().toString();
                String phone = regPhone.getEditText().getText().toString();

                Intent i = new Intent(getApplicationContext(),verifyphone.class);
                i.putExtra("PhoneNo",phone);
                startActivity(i);

                UserHelperClass helperClass = new UserHelperClass( username,name, password, email, phone);
                reference.child(username).setValue(helperClass);
                startActivity(new Intent(SignUp.this, verifyphone.class));

            }
        });



    }
}
